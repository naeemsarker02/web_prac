import React from "react";
import { createBrowserRouter, RouterProvider } from 'react-router-dom'; //RouterProvider: Renders the router into your app.
import Home from './Pages/Home/Home';
import About from './Pages/About/About';
import Contact from './Pages/Contact/Contact';
import Counter from "./Pages/Counter/Counter";
import Register from "./Pages/Register/Register";

import 'animate.css'; // animation support
import 'bootstrap/dist/css/bootstrap.min.css'; // make sure Bootstrap is imported




const router = createBrowserRouter([
  {
    path: '/',
    element:<Home/>
  },
  {
    path: '/about',
    element:<About/>
  },
  {
    path: '/Contact',
    element:<Contact/>
  },
  {
    path: '/counter',
    element:<Counter/>
  },
  {
    path: '/register',
    element: <Register/>
  }

])


const App = () => {
  return (
    <RouterProvider router={router}/>
  )
}

export default App;
