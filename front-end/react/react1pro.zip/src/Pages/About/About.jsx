import React, { useState } from 'react'
import Header from '../../Components/Header'

const About = () => {
  const [darkMode, setDarkMode] = useState(false);

  const toggleTheme = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div>
      <Header />
      <div className="theme">
        <div className={darkMode ? "dark" : "light"}>
          <h1>{darkMode ? "Dark Mode" : "Light Mode"}</h1>
          <button onClick={toggleTheme}>
            Switch to {darkMode ? "Light" : "Dark"} Mode
          </button>
        </div>
      </div>
    </div>
  )
}

export default About