import React from 'react'
import Header from '../../Components/Header';
import ShuffleHero from '../../Components/ShuffleHero';
import Footer from '../../Components/Footer';

const Home = () => {
  return (
    <div> 
       <Header/>
       <ShuffleHero/>
       <Footer/>
    </div>
  )
}

export default Home;