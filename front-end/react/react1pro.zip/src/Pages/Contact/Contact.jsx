import React from 'react'
import Header from '../../Components/Header';
import ShuffleHero from '../../Components/ShuffleHero';

const Contact = () => {
  return (
    <div> 
      <Header/>
      <div className="hero">
        <ShuffleHero/>
      </div>
    </div>
  )
}

export default Contact;