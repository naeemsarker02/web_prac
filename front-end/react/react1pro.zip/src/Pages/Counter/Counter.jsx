import React, { useState } from 'react'
import Header from '../../Components/Header'
const Counter = () => {

  const [count, setCount] = useState(0);

  const increase = ()=>{
    setCount(count+1);
  }

  const decrease = ()=>{
    setCount(count-1);
  }

  const reset = ()=>{
    setCount(0);
  }


  return (
    <div>
      <Header/>

      <div className="C_hero">
        <div className="counter_machine">
          <div className="result">
            {count}
          </div>
          <div className="btnss">
            <button onClick={increase}>+</button>
            <button onClick={reset}>🔁</button>
            <button onClick={decrease}>-</button>
          </div>
        </div>
      </div>
    </div>
  )
};

export default Counter