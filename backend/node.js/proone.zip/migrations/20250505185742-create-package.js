'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Packages', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      P_cat_id: {
        type: Sequelize.INTEGER
      },
      title: {
        type: Sequelize.STRING
      },
      price: {
        type: Sequelize.STRING
      },
      short_details: {
        type: Sequelize.STRING
      },
      photo_service: {
        type: Sequelize.STRING
      },
      video_service: {
        type: Sequelize.STRING
      },
      delivery_service: {
        type: Sequelize.STRING
      },
      Package_type_id: {
        type: Sequelize.INTEGER
      },
      drone_service: {
        type: Sequelize.STRING
      },
      Equipments: {
        type: Sequelize.STRING
      },
      Status: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Packages');
  }
};