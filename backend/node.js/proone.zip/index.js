const express = require('express');
const app = express();
const dotenv = require('dotenv').config();
const port = process.env.PORT || 4920;
const cors = require('cors');
const path = require('path');
const Packages_categoriesRoute = require('./router/Packages_categoriesRoute');
const packageTypeRouter = require('./router/packageTypeRouter');
const packageRoute = require('./router/packageRoute');




app.use(express.json());
app.use(cors());

app.use('/upload',express.static(path.join(__dirname,'/Upload')));

app.use('/pc',Packages_categoriesRoute);
app.use('/pt',packageTypeRouter);
app.use('/package',packageRoute);

app.listen(port, "0.0.0.0",(err) => {
    if (err) {
        console.log(err);
    } else {
        console.log(`Server is running on port ${port}`);
    }});
