'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class PackageType extends Model {
  
    static associate(models) {
      // define association here
    }
  }
  PackageType.init({
    type: DataTypes.STRING,
    img: DataTypes.STRING,
    status: DataTypes.BOOLEAN
  }, {
    sequelize,
    modelName: 'PackageType',
  });
  return PackageType;
};