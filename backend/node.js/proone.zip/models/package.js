'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Package extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Package.init({
    P_cat_id: DataTypes.INTEGER,
    title: DataTypes.STRING,
    price: DataTypes.STRING,
    short_details: DataTypes.STRING,
    photo_service: DataTypes.STRING,
    video_service: DataTypes.STRING,
    delivery_service: DataTypes.STRING,
    Package_type_id: DataTypes.INTEGER,
    drone_service: DataTypes.STRING,
    Equipments: DataTypes.STRING,
    Status: DataTypes.BOOLEAN
  }, {
    sequelize,
    modelName: 'Package',
  });
  return Package;
};